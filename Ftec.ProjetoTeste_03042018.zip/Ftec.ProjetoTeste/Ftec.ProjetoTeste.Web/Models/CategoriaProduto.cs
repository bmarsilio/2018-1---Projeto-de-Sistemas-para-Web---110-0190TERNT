﻿using System;

namespace Ftec.ProjetoTeste.Web.Models
{
    public class CategoriaProduto
    {
        public Guid Id { get; set; }
        public string Descricao { get; set; }
    }
}